package com.dhanjyothi.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "BENEFICIARY")
public class Beneficiary implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BEN_ID", unique = true, nullable = false)
	private Integer id;

	
	@Column(name = "OWNER_ID",  nullable = false) // user id of user table. 
	private String ownerId;

	
	@Column(name = "BEN_TYPE",  nullable = false)
	private String benType;

	
	@Column(name = "BEN_NICK_NAME",  nullable = false)
	private String benNickName;

	
	@Column(name = "BEN_ACCT_NUM",  nullable = false)
	private String benAccountNumber;


	@Column(name = "BEN_BANK", nullable = false)
	private String benBank;


	@Column(name = "BEN_BANK_IFSC", nullable = false)
	private String benBankIFSC;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getBenType() {
		return benType;
	}

	public void setBenType(String benType) {
		this.benType = benType;
	}

	public String getBenNickName() {
		return benNickName;
	}

	public void setBenNickName(String benNickName) {
		this.benNickName = benNickName;
	}

	public String getBenAccountNumber() {
		return benAccountNumber;
	}

	public void setBenAccountNumber(String benAccountNumber) {
		this.benAccountNumber = benAccountNumber;
	}

	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	public String getBenBankIFSC() {
		return benBankIFSC;
	}

	public void setBenBankIFSC(String benBankIFSC) {
		this.benBankIFSC = benBankIFSC;
	}

	
}
