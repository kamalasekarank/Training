package com.dhanjyothi.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSACTION")
public class Transaction implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TRN_ID", unique = true, nullable = false)
	private Integer id;

	
	@Column(name = "TRN_TYPE",  nullable = false)
	private String transType;


	@Column(name = "TRN_DESC",  nullable = false)
	private String transDesc;


	@Column(name = "TRN_AMT",  nullable = false)
	private Float transAmount;


	@Column(name = "TRN_DT_TIME",  nullable = false)
	private Date transDateTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	public Float getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(Float transAmount) {
		this.transAmount = transAmount;
	}

	public Date getTransDateTime() {
		return transDateTime;
	}

	public void setTransDateTime(Date transDateTime) {
		this.transDateTime = transDateTime;
	}



}
