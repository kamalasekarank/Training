package com.dhanjyothi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "KYC_DOCUMENT")
public class KycFile {
	
	@Id
	@GeneratedValue
	@Column(name = "KYC_ID")
	private long id;
	
	@Column(name = "USER_ID")
	private String userId;
	
	@Column(name = "KYC_TYPE")
	private String kycType;
	
	@Column(name = "DOCUMENT_DESC")
	private String docDescription;
	
	@Column(name = "FILE_DATA")
	private byte[] data;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public byte[] getData() {
		return data;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getKycType() {
		return kycType;
	}

	public void setKycType(String kycType) {
		this.kycType = kycType;
	}

	public String getDocDescription() {
		return docDescription;
	}

	public void setDocDescription(String docDescription) {
		this.docDescription = docDescription;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
