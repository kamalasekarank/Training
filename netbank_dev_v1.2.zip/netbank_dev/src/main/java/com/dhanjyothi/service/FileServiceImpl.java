package com.dhanjyothi.service;

import org.springframework.transaction.annotation.Transactional;


@Transactional
public class FileServiceImpl implements FileService{

	

	
}
