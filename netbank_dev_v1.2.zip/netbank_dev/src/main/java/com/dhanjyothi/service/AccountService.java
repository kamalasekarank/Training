package com.dhanjyothi.service;

import java.util.List;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiary;
import com.dhanjyothi.model.ServiceRequest;
import com.dhanjyothi.model.Transaction;

public interface AccountService {

	Account findByAccountId(int id);

	void saveAccount(Account account);

	void updateAccount(Account account);

	List<Account> findAllAccounts();

	void saveBeneficiary(Beneficiary beneficiary);

	List<Beneficiary> findAllBeneficiary();
	
	
	void saveServiceRequest(ServiceRequest serviceRequest);

	List<ServiceRequest> findAllServiceRequest();
	List<Transaction> findAllTransaction();
	void doTransaction(Transaction transaction);
}