package com.dhanjyothi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;

import com.dhanjyothi.dao.UserDao;
import com.dhanjyothi.model.User;



@Transactional
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	private UserDao dao;

	@Autowired
    private PasswordEncoder passwordEncoder;
	
	public void saveUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		dao.save(user);
	}
	public List<User> findAllUsers() {
		return dao.findAllUsers();
	}


	
}
