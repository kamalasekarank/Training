package com.dhanjyothi.service;

import com.dhanjyothi.model.User;


public interface RegisterService {
	void saveUser(User user);
}