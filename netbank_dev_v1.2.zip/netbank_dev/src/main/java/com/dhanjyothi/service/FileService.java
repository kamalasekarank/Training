package com.dhanjyothi.service;

public interface FileService {

}