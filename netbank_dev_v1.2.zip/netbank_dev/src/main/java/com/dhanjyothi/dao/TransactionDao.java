package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.Transaction;

public interface TransactionDao {
	List<Transaction> findAllTransaction();
	void doTransaction(Transaction transaction);
}
