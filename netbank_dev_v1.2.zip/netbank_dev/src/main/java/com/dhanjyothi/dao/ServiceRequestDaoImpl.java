package com.dhanjyothi.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.springframework.stereotype.Repository;

import com.dhanjyothi.model.ServiceRequest;

@Repository
public class ServiceRequestDaoImpl extends AbstractDao<Integer, ServiceRequest> implements ServiceRequestDao {

	public ServiceRequest findByServiceRequest(int id) {
		ServiceRequest serviceRequest = getByKey(id);
		return serviceRequest;
	}

	@SuppressWarnings("unchecked")
	public List<ServiceRequest> findAllServiceRequest() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("customerId"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);//To avoid duplicates.
		return (List<ServiceRequest>) criteria.list();
	}

	public void save(ServiceRequest serviceRequest) {
		System.out.println(serviceRequest.toString());
		persist(serviceRequest);
	}

}
