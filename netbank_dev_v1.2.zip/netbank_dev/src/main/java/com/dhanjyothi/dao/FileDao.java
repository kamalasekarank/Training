package com.dhanjyothi.dao;

import com.dhanjyothi.model.KycFile;

public interface FileDao {
	void save(KycFile uploadFile);
}
