package com.dhanjyothi.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dhanjyothi.model.KycFile;

@Repository
public class FileDaoImpl implements FileDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public FileDaoImpl() {
	}

	public FileDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	@Transactional
	public void save(KycFile uploadFile) {
		sessionFactory.getCurrentSession().save(uploadFile);
	}

}
