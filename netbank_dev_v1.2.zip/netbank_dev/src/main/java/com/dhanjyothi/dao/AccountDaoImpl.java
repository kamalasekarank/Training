package com.dhanjyothi.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.springframework.stereotype.Repository;
import com.dhanjyothi.model.Account;

@Repository("accountDao")
public class AccountDaoImpl extends AbstractDao<Integer, Account> implements AccountDao {

	public Account findByAccountId(int id) {
		Account account = getByKey(id);
		return account;
	}

	@SuppressWarnings("unchecked")
	public List<Account> findAllAccounts() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("accountHolderId"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);//To avoid duplicates.
		return (List<Account>) criteria.list();
	}

	public void save(Account account) {
		System.out.println(account.toString());
		persist(account);
	}
}
