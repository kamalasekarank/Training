package com.dhanjyothi.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.springframework.stereotype.Repository;

import com.dhanjyothi.model.Transaction;

@Repository
public class TransactionDaoImpl extends AbstractDao<Integer, Transaction> implements TransactionDao {
	@SuppressWarnings("unchecked")
	public List<Transaction> findAllTransaction() {
		Criteria criteria = createEntityCriteria().addOrder(Order.desc("transDateTime"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);//To avoid duplicates.
		return (List<Transaction>) criteria.list();
	}

	public void doTransaction(Transaction transaction) {
		
		persist(transaction);
	}

}
