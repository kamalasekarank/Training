package com.dhanjyothi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class UploadController {
	private static final String UPLOAD_DIRECTORY ="/images";
	private static final int THRESHOLD_SIZE     = 1024 * 1024 * 3;  // 3MB
	
//	@Autowired
//	CommonsMultipartResolver multipartResolver;
//	
//	@RequestMapping("uploadform")
//	public ModelAndView uploadForm(){
//		return new ModelAndView("uploadform");	
//	}
//	@RequestMapping(value = "/savefile", method = {RequestMethod.GET,RequestMethod.POST})
//	public ModelAndView saveimage( @RequestParam CommonsMultipartFile file,HttpSession session) throws Exception
//	{
//	DiskFileItemFactory factory = new DiskFileItemFactory();
//	factory.setSizeThreshold(THRESHOLD_SIZE);
//	factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
//	 
//	ServletFileUpload upload = new ServletFileUpload(factory);
//	ServletContext context = session.getServletContext();
//
//	String uploadPath = context.getRealPath(UPLOAD_DIRECTORY);
//	System.out.println(uploadPath);	    
//
//	byte[] bytes = file.getBytes();
//	BufferedOutputStream stream =new BufferedOutputStream(new FileOutputStream(new File(uploadPath + File.separator + file.getOriginalFilename())));
//	stream.write(bytes);
//	stream.flush();
//	stream.close();
//	     
//	return new ModelAndView("uploadform","filesuccess","File successfully saved!");
//	}
}
