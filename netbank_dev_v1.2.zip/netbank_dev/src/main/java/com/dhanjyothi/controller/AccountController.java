package com.dhanjyothi.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiary;
import com.dhanjyothi.model.ServiceRequest;
import com.dhanjyothi.service.AccountService;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class AccountController {

	@Autowired
	AccountService accountService;
	@Autowired
	MessageSource messageSource;
	@Autowired
	PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices;
	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newAccount" }, method = RequestMethod.GET)
	public String newAccount(ModelMap model) {
		Account account = new Account();
		model.addAttribute("account", account);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "newSbAccount";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newAccount" }, method = RequestMethod.POST)
	public String saveAccount(@Valid Account account, BindingResult result, ModelMap model) {
		System.out.println("call here save account :: " + result.toString());

		System.out.println("call here :: " + result.toString());
		if (result.hasErrors()) {
			return "newSbAccount";
		}
		account.setAccountCreatedDate(new Date());
		account.setAccountUpdateDate(new Date());
		account.setAccountStatus("A");
		accountService.saveAccount(account);
		return "accountsummary";
	}

	/**
	 * This method will provide the medium to update an existing user.
	 */
	@RequestMapping(value = { "/edit-account-{accountId}" }, method = RequestMethod.GET)
	public String editAccount(@PathVariable int accountId, ModelMap model) {
		Account account = accountService.findByAccountId(accountId);
		model.addAttribute("account", account);
		model.addAttribute("edit", true);
		model.addAttribute("loggedinuser", getPrincipal());
		return "newSbAccount";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * updating user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/edit-account-{accountId}" }, method = RequestMethod.POST)
	public String updateAccount(@Valid Account account, BindingResult result, ModelMap model,
			@PathVariable String accountId) {

		if (result.hasErrors()) {
			return "registration";
		}
		accountService.updateAccount(account);
		model.addAttribute("loggedinuser", getPrincipal());
		return "accountsummary";
	}
	
	/**
	 * This method will list all existing users.
	 */
	@RequestMapping(value = { "/", "/list" }, method = RequestMethod.GET)
	public String listAccounts(ModelMap model) {

		List<Account> account = accountService.findAllAccounts();
		model.addAttribute("account", account);
		model.addAttribute("loggedinuser", getPrincipal());
		return "accountsummary";
	}

	private String getPrincipal() {
		String userId = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userId = ((UserDetails) principal).getUsername();
		} else {
			userId = principal.toString();
		}
		return userId;
	}
	
	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newBeneficiary" }, method = RequestMethod.GET)
	public String newBeneficiary(ModelMap model) {
		Beneficiary beneficary = new Beneficiary();
		model.addAttribute("beneficiary", beneficary);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "addbeneficiary";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newBeneficiary" }, method = RequestMethod.POST)
	public String saveBeneficiary(@Valid Beneficiary beneficiary, BindingResult result, ModelMap model) {
		System.out.println("call here save account :: " + result.toString());

		System.out.println("call here :: " + result.toString());
		if (result.hasErrors()) {
			return "addbeneficiary";
		}
	
		accountService.saveBeneficiary(beneficiary);
		List<Beneficiary> beneficiaryList = accountService.findAllBeneficiary();
		model.addAttribute("beneficiary", beneficiaryList);
		model.addAttribute("loggedinuser", getPrincipal());
		
		return "beneficiary";
	}
	
	@RequestMapping(value =  "/listbene" , method = RequestMethod.GET)
	public String listBeneficiary(ModelMap model) {
		List<Beneficiary> beneficiary = accountService.findAllBeneficiary();
		model.addAttribute("beneficiary", beneficiary);
		model.addAttribute("loggedinuser", getPrincipal());
		return "beneficiary";
	}
	
	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newServiceRequest" }, method = RequestMethod.GET)
	public String newServiceRequest(ModelMap model) {
		ServiceRequest serviceRequest = new ServiceRequest();
		model.addAttribute("serviceRequest", serviceRequest);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "addServiceRequest";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newServiceRequest" }, method = RequestMethod.POST)
	public String saveServiceRequest(@Valid ServiceRequest serviceRequest, BindingResult result, ModelMap model) {
		System.out.println("call here save account :: " + result.toString());

		System.out.println("call here :: " + result.toString());
		if (result.hasErrors()) {
			return "addServiceRequest";
		}
	
		accountService.saveServiceRequest(serviceRequest);
		List<ServiceRequest> serviceRequestList = accountService.findAllServiceRequest();
		model.addAttribute("serviceRequests", serviceRequestList);
		model.addAttribute("loggedinuser", getPrincipal());
		
		return "checkbook";
	}
	
	@RequestMapping(value =  "//listserreq" , method = RequestMethod.GET)
	public String listServiceRequest(ModelMap model) {
		List<ServiceRequest> serviceRequests = accountService.findAllServiceRequest();
		model.addAttribute("serviceRequests", serviceRequests);
		model.addAttribute("loggedinuser", getPrincipal());
		return "checkbook";
	}
	
}