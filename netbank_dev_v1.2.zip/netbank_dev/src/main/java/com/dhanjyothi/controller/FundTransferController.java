package com.dhanjyothi.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Transaction;
import com.dhanjyothi.service.AccountService;
import com.dhanjyothi.service.LoginService;;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class FundTransferController {
	
	@Autowired
	AccountService accountService;
	@Autowired
	LoginService userService;
	
	@Autowired
	MessageSource messageSource;
	@Autowired
	PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices;
	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newTransaction" }, method = RequestMethod.GET)
	public String newServiceRequest(ModelMap model) {
		Transaction transaction = new Transaction();
		model.addAttribute("transaction", transaction);
		model.addAttribute("edit", false);
		return "fundTransfer";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newTransaction" }, method = RequestMethod.POST)
	public String saveTransaction(@Valid Transaction transaction, BindingResult result, ModelMap model) {
		System.out.println("call here save account :: " + result.toString());

		System.out.println("call here :: " + result.toString());
		if (result.hasErrors()) {
			return "fundTransfer";
		}
		transaction.setTransDateTime(new Date());
		accountService.doTransaction(transaction);
		
		//detect the amount from original balance
		Account account = accountService.findByAccountId(2);
		System.out.println("account ::"+account);
		Float accountbalance = (account.getAccountBalance() - transaction.getTransAmount());
		account.setAccountBalance(accountbalance);
		accountService.updateAccount(account);
		
		List<Transaction> transactionList = accountService.findAllTransaction();
		model.addAttribute("transactions", transactionList);
		return "transactions";
	}
	
	@RequestMapping(value =  "//listtrans" , method = RequestMethod.GET)
	public String listTransaction(ModelMap model) {
		List<Transaction> transactions = accountService.findAllTransaction();
		model.addAttribute("transactions", transactions);
		
		return "transactions";
	}

}