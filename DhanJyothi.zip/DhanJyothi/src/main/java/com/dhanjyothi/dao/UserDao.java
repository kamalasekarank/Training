package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.User;


public interface UserDao {
	User findByUserId(int id);
	User findByUserName(String sso);
	void save(User user);
	void deleteByUserId(int userId);
	void updateUser(User user);
	List<User> findAllUsers();
}

