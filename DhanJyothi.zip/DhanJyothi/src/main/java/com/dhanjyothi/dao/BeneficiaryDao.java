package com.dhanjyothi.dao;

import java.util.List;


import com.dhanjyothi.model.Beneficiary;

public interface BeneficiaryDao {
	Beneficiary findByBeneficiaryId(int id);
	List<Beneficiary> findAllBeneficiary(int userId);
	void save(Beneficiary beneficiary);
}
