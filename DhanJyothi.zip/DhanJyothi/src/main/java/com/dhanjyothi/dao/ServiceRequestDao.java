package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.ServiceRequest;

public interface ServiceRequestDao {
	ServiceRequest findByServiceRequest(int id);
	List<ServiceRequest> findAllServiceRequest();
	void save(ServiceRequest serviceRequest);
}
