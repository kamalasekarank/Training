package com.dhanjyothi.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dhanjyothi.model.Beneficiary;

@Repository
public class BeneficiaryDaoImpl extends AbstractDao<Integer, Beneficiary> implements BeneficiaryDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public void save(Beneficiary beneficiary) {
		sessionFactory.getCurrentSession().save(beneficiary);
	}

	public Beneficiary findByBeneficiaryId(int id) {
		Beneficiary beneficiary = getByKey(id);
		return beneficiary;
	}

	@SuppressWarnings("unchecked")
	public List<Beneficiary> findAllBeneficiary(int userId) {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("ownerId", userId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);//To avoid duplicates.
		return (List<Beneficiary>) criteria.list();
	}

	
	
}
