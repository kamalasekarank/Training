package com.dhanjyothi.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dhanjyothi.model.KycFile;

@Repository
public class FileUploadDAOImpl extends AbstractDao<Integer, KycFile> implements FileUploadDAO {
	@Autowired
	private SessionFactory sessionFactory;

	public FileUploadDAOImpl() {
	}

	public FileUploadDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	@Transactional
	public void save(KycFile uploadFile) {
		uploadFile.setId(101);
		sessionFactory.getCurrentSession().save(uploadFile);
	}

	@Override
	@Transactional
	public List<KycFile> findDocumentByUserId(String userName) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("userId", userName));
		return (List<KycFile>) crit.list();
	}

	@Override
	@Transactional
	public KycFile findByKycFileId(int id) {
		KycFile kycFile = getByKey(id);
		return kycFile;
	}

	@Override
	@Transactional
	public void removeKycDocbyUser(String userId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("userId", userId));
		List<KycFile> kycFiles = (List<KycFile>) crit.list();
		for (KycFile kycFile : kycFiles)
			delete(kycFile);
	}

}
