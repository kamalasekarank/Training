package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.Account;

public interface AccountDao {
	Account findByAccountId(int id);
	List<Account> findAllAccounts(int userId);
	void save(Account account);
	Account findByAccountUserId(int id) ;
}
