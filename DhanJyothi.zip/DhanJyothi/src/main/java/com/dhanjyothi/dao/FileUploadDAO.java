package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.KycFile;

public interface FileUploadDAO {
	void save(KycFile uploadFile);
	List<KycFile> findDocumentByUserId(String userName);
	KycFile findByKycFileId(int kycId);
	void removeKycDocbyUser(String userId);
}
