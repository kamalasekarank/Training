package com.dhanjyothi.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.dhanjyothi.model.Account;

@Repository("accountDao")
public class AccountDaoImpl extends AbstractDao<Integer, Account> implements AccountDao {

	public Account findByAccountId(int id) {
		Account account = getByKey(id);
		return account;
	}

	@SuppressWarnings("unchecked")
	public List<Account> findAllAccounts(int userId) {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("id"));
		criteria.add(Restrictions.eq("accountType", "T"));
		criteria.add(Restrictions.eq("accountHolderId", userId));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		return (List<Account>) criteria.list();
	}

	public void save(Account account) {
		System.out.println(account.toString());
		persist(account);
	}

	public Account findByAccountUserId(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("accountHolderId", id));
		crit.add(Restrictions.eq("accountType", "S"));
		Account account = (Account) crit.uniqueResult();
		return account;
	}

}
