package com.dhanjyothi.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BENEFICIARY")
public class Beneficiary implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BEN_ID", unique = true, nullable = false)
	private Integer id;

	@Column(name = "OWNER_ID", nullable = false) // user id of user table.
	private Integer ownerId;

	@Column(name = "BEN_TYPE", nullable = false) // I --> Internal , E --> External
	private String benType;

	@Column(name = "BEN_NICK_NAME", nullable = false) // Reference name
	private String benNickName;

	@Column(name = "BEN_ACCT_NUM", nullable = false) // Account number of the payee
	private Integer benAccountNumber;

	@Column(name = "BEN_BANK", nullable = true) // external bank
	private String benBank;

	@Column(name = "BEN_BANK_IFSC", nullable = true) // external IFSC
	private String benBankIFSC;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public void setBenAccountNumber(Integer benAccountNumber) {
		this.benAccountNumber = benAccountNumber;
	}

	public String getBenType() {
		return benType;
	}

	public void setBenType(String benType) {
		this.benType = benType;
	}

	public String getBenNickName() {
		return benNickName;
	}

	public void setBenNickName(String benNickName) {
		this.benNickName = benNickName;
	}

	public Integer getBenAccountNumber() {
		return benAccountNumber;
	}

	public String getBenBank() {
		return benBank;
	}

	public void setBenBank(String benBank) {
		this.benBank = benBank;
	}

	public String getBenBankIFSC() {
		return benBankIFSC;
	}

	public void setBenBankIFSC(String benBankIFSC) {
		this.benBankIFSC = benBankIFSC;
	}

}
