package com.dhanjyothi.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ACCOUNT")
public class Account implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ACCT_ID", unique = true, nullable = false)
	private Integer id;

	@Column(name = "ACCT_HOLDER_ID", nullable = false)
	private Integer accountHolderId;

	@Column(name = "ACCT_TYPE", nullable = false)
	private String accountType;

	@Column(name = "INT_RATE", nullable = false)
	private Float intRate;

	@Column(name = "ACC_BALANCE", nullable = false)
	private Float accountBalance;

	@Column(name = "DEPOSIT_TENURE", nullable = false)
	private Integer depositTenure;

	@Column(name = "MATURITY_AMT", nullable = false)
	private Float maturityAmount;

	@Column(name = "ACCOUNT_CREATED_DATE", nullable = false)
	private Date accountCreatedDate;

	@Column(name = "ACCOUNT_UPDATE_DATE", nullable = false)
	private Date accountUpdateDate;

	@Column(name = "ACC_STATUS", nullable = false)
	private String accountStatus;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAccountHolderId() {
		return accountHolderId;
	}

	public void setAccountHolderId(Integer accountHolderId) {
		this.accountHolderId = accountHolderId;
	}

	public Float getIntRate() {
		return intRate;
	}

	public void setIntRate(Float intRate) {
		this.intRate = intRate;
	}

	public Integer getDepositTenure() {
		return depositTenure;
	}

	public void setDepositTenure(Integer depositTenure) {
		this.depositTenure = depositTenure;
	}

	public Float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(Float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Float getMaturityAmount() {
		return maturityAmount;
	}

	public void setMaturityAmount(Float maturityAmount) {
		this.maturityAmount = maturityAmount;
	}

	public Date getAccountCreatedDate() {
		return accountCreatedDate;
	}

	public void setAccountCreatedDate(Date accountCreatedDate) {
		this.accountCreatedDate = accountCreatedDate;
	}

	public Date getAccountUpdateDate() {
		return accountUpdateDate;
	}

	public void setAccountUpdateDate(Date accountUpdateDate) {
		this.accountUpdateDate = accountUpdateDate;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

}
