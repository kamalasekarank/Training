package com.dhanjyothi.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiary;
import com.dhanjyothi.model.ServiceRequest;
import com.dhanjyothi.model.Transaction;
import com.dhanjyothi.model.User;
import com.dhanjyothi.service.AccountService;
import com.dhanjyothi.service.LoginService;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class AccountController {
	@Autowired
	LoginService userService;
	@Autowired
	AccountService accountService;
	@Autowired
	MessageSource messageSource;
	@Autowired
	PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices;
	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

	@RequestMapping(value = { "/newAccount" }, method = RequestMethod.GET)
	public String newAccount(ModelMap model) {
		Account account = new Account();
		account.setAccountType("S");
		account.setAccountBalance(10000.00f);
		String userName = getPrincipal();
		User user = userService.findByUserName(userName);
		account.setAccountHolderId(user.getId());
		account.setIntRate(getSBAccountInterestRate());
		account.setAccountStatus("A");
		account.setAccountCreatedDate(new Date());
		account.setAccountUpdateDate(new Date());
		account.setDepositTenure(0);
		account.setMaturityAmount(0.0f);
		accountService.saveAccount(account);

		model.addAttribute("account", account);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", userName);

		return "accountsummary";
	}

	@RequestMapping(value = { "/newTermAccount" }, method = RequestMethod.GET)
	public String newTermAccount(ModelMap model) {
		model.addAttribute("account", new Account());
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "newTermAccount";
	}

	@RequestMapping(value = { "/newTermAccount" }, method = RequestMethod.POST)
	public String saveNewTermAccount(@Valid Account account, BindingResult result, ModelMap model) {
		System.out.println(account.getId());
		if (result.hasErrors()) {
			return "newTermAccount";
		}

		account.setAccountType("T");
		String userName = getPrincipal();
		User user = userService.findByUserName(userName);
		account.setAccountHolderId(user.getId());
		account.setIntRate(getTermAccountInterestRate());
		account.setAccountStatus("A");
		account.setAccountCreatedDate(new Date());
		account.setAccountUpdateDate(new Date());
		Float interestRate = account.getIntRate() / 100;
		account.setMaturityAmount(
				getMaturityAmount(account.getAccountBalance(), account.getDepositTenure(), interestRate));
		accountService.saveAccount(account);

		user = userService.findByUserName(userName);
		Account sbAccount = accountService.findByAccountUserId(user.getId());
		System.out.println(sbAccount);

		sbAccount.setAccountBalance(sbAccount.getAccountBalance() - account.getAccountBalance());
		accountService.updateAccount(sbAccount);

		Transaction transaction = new Transaction();
		transaction.setTransType("Transfer to created Term Account " + account.getId());
		transaction.setTransDesc(" Term account created ");
		transaction.setTransAmount(account.getAccountBalance());
		transaction.setTransDateTime(new Date());
		transaction.setLoggedUserId(user.getId());
		accountService.doTransaction(transaction);

		model.addAttribute("account", sbAccount);
		model.addAttribute("termAccounts", accountService.findAllAccounts(user.getId()));
		model.addAttribute("loggedinuser", getPrincipal());
		return "accountsummary";
	}

	private Float getMaturityAmount(Float amount, Integer tenure, Float interestRate) {
		return amount + (amount * tenure * interestRate);
	}

	private Float getSBAccountInterestRate() {
		return 8.5f;
	}

	private Float getTermAccountInterestRate() {

		// Add the logic based on years of deposit
		return 8.2f;
	}

	/**
	 * This method will list all existing users.
	 */
	@RequestMapping(value = { "/", "/list" }, method = RequestMethod.GET)
	public String listAccounts(ModelMap model) {
		User user = userService.findByUserName(getPrincipal());
		Account sbAccount = accountService.findByAccountUserId(user.getId());
		model.addAttribute("account", sbAccount);
		model.addAttribute("termAccounts", accountService.findAllAccounts(user.getId()));
		model.addAttribute("loggedinuser", getPrincipal());
		List<User> users = userService.findAllUsers();
		model.addAttribute("users", users);
		return "accountsummary";
	}

	private String getPrincipal() {
		String userId = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userId = ((UserDetails) principal).getUsername();
		} else {
			userId = principal.toString();
		}
		return userId;
	}

	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newBeneficiary" }, method = RequestMethod.GET)
	public String newBeneficiary(ModelMap model) {
		Beneficiary beneficary = new Beneficiary();
		model.addAttribute("beneficiary", beneficary);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "addbeneficiary";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newBeneficiary" }, method = RequestMethod.POST)
	public String saveBeneficiary(@Valid Beneficiary beneficiary, BindingResult result, ModelMap model) {
		if (result.hasErrors()) {
			return "addbeneficiary";
		}
		User user = userService.findByUserName(getPrincipal());
		beneficiary.setOwnerId(user.getId());
		accountService.saveBeneficiary(beneficiary);
		List<Beneficiary> beneficiaryList = accountService.findAllBeneficiary(user.getId());
		model.addAttribute("beneficiary", beneficiaryList);
		model.addAttribute("loggedinuser", getPrincipal());

		return "beneficiary";
	}

	@RequestMapping(value = "/listbene", method = RequestMethod.GET)
	public String listBeneficiary(ModelMap model) {
		User user = userService.findByUserName(getPrincipal());
		System.out.println(user.getId());
		List<Beneficiary> beneficiary = accountService.findAllBeneficiary(user.getId());
		model.addAttribute("beneficiary", beneficiary);
		model.addAttribute("loggedinuser", getPrincipal());
		return "beneficiary";
	}

	@RequestMapping(value = "/navFundTransfer-{benId}")
	public String navFundTransfer(ModelMap model, @PathVariable int benId) {

		Beneficiary beneficiary = accountService.findByBeneficiaryId(benId);
		Transaction transaction = new Transaction();
		model.addAttribute("transaction", transaction);
		model.addAttribute("beneficiary", beneficiary);
		model.addAttribute("loggedinuser", getPrincipal());
		return "fundTransfer";
	}

	@RequestMapping(value = { "/newServiceRequest" }, method = RequestMethod.GET)
	public String newServiceRequest(ModelMap model) {
		ServiceRequest serviceRequest = new ServiceRequest();
		model.addAttribute("serviceRequest", serviceRequest);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "addServiceRequest";
	}

	@RequestMapping(value = { "/newServiceRequest" }, method = RequestMethod.POST)
	public String saveServiceRequest(@Valid ServiceRequest serviceRequest, BindingResult result, ModelMap model,
			HttpServletRequest request) {
		if (result.hasErrors()) {
			return "addServiceRequest";
		}
		String noOfLeaf = request.getParameter("noOfLeaf");

		User user = userService.findByUserName(getPrincipal());
		serviceRequest.setCustomerId(user.getId());
		serviceRequest.setRequestDescription(noOfLeaf + " : " + serviceRequest.getRequestDescription());
		Account sbAccount = accountService.findByAccountUserId(user.getId());
		System.out.println(sbAccount);

		sbAccount.setAccountBalance(
				sbAccount.getAccountBalance() - getChargesbyRequestedLeaf(request.getParameter("noOfLeaf")));
		accountService.updateAccount(sbAccount);

		accountService.saveServiceRequest(serviceRequest);
		Transaction transaction = new Transaction();
		transaction.setTransType("Request for Check book");
		transaction.setTransDesc(" Checkbook leaf" + noOfLeaf);
		transaction.setTransAmount(getChargesbyRequestedLeaf(request.getParameter("noOfLeaf")));
		transaction.setTransDateTime(new Date());
		transaction.setLoggedUserId(user.getId());
		accountService.doTransaction(transaction);

		List<ServiceRequest> serviceRequestList = accountService.findAllServiceRequest();
		model.addAttribute("serviceRequests", serviceRequestList);
		model.addAttribute("loggedinuser", getPrincipal());

		return "checkbook";
	}

	private Float getChargesbyRequestedLeaf(String requestedLeaf) {
		if (requestedLeaf.equals("20"))
			return 100.0f;
		else if (requestedLeaf.equals("50"))
			return 200.0f;
		else if (requestedLeaf.equals("100"))
			return 300.0f;
		return 0.0f;
	}

	@RequestMapping(value = "//listserreq", method = RequestMethod.GET)
	public String listServiceRequest(ModelMap model) {
		List<ServiceRequest> serviceRequests = accountService.findAllServiceRequest();
		model.addAttribute("serviceRequests", serviceRequests);
		model.addAttribute("loggedinuser", getPrincipal());
		return "checkbook";
	}
}