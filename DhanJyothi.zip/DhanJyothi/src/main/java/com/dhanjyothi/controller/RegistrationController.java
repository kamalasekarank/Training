package com.dhanjyothi.controller;

import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dhanjyothi.dao.FileUploadDAO;
import com.dhanjyothi.model.User;
import com.dhanjyothi.service.LoginService;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class RegistrationController {
	@Autowired
	LoginService userService;
	@Autowired
	MessageSource messageSource;
	@Autowired
	private FileUploadDAO fileUploadDao;
	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

	@RequestMapping(value = { "/newuser" }, method = RequestMethod.GET)
	public String newUser(ModelMap model) {
		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "registration";
	}

	@RequestMapping(value = { "/newuser" }, method = RequestMethod.POST)
	public String saveUser(@Valid User user, BindingResult result, ModelMap model) {
		if (result.hasErrors()) {
			return "registration";
		}
		if (!userService.isUserSSOUnique(user.getId(), user.getUserName())) {
			FieldError ssoError = new FieldError("user", "userId", messageSource.getMessage("non.unique.userId",
					new String[] { user.getUserName() }, Locale.getDefault()));
			result.addError(ssoError);
			return "registration";
		}
		userService.saveUser(user);
		model.addAttribute("loggedinuser", getPrincipal());
		return "Upload";
	}

	@RequestMapping(value = { "/edit-user-{userId}" }, method = RequestMethod.GET)
	public String editUser(@PathVariable int userId, ModelMap model) {
		User user = userService.findByUserId(userId);
		user.setUserStatus("A");

		userService.updateUser(user);
		model.addAttribute("loggedinuser", getPrincipal());
		List<User> users = userService.findAllUsers();
		model.addAttribute("users", users);
		return "accountsummary";
	}

	@RequestMapping(value = { "delete-user-{userId}" }, method = RequestMethod.GET)
	public String removeUser(@PathVariable int userId, ModelMap model) {
		User regUser = userService.findByUserId(userId);
		fileUploadDao.removeKycDocbyUser(regUser.getUserName());
		userService.deleteUserByUserId(userId);
		model.addAttribute("loggedinuser", getPrincipal());
		List<User> users = userService.findAllUsers();
		model.addAttribute("users", users);
		return "accountsummary";
	}

	private String getPrincipal() {
		String userId = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userId = ((UserDetails) principal).getUsername();
		} else {
			userId = principal.toString();
		}
		return userId;
	}
}