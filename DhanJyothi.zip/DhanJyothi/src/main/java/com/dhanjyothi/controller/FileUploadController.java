package com.dhanjyothi.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.dhanjyothi.dao.FileUploadDAO;
import com.dhanjyothi.model.KycFile;

/**
 * Handles requests for the file upload page.
 */
@Controller
public class FileUploadController {
	@Autowired
	private FileUploadDAO fileUploadDao;

	@RequestMapping(value = "/doUpload", method = RequestMethod.GET)
	public String showUploadForm(HttpServletRequest request) {
		return "Upload";
	}

	@RequestMapping(value = "/doUpload", method = RequestMethod.POST)
	public String handleFileUpload(HttpServletRequest request, @RequestParam CommonsMultipartFile[] fileUpload)
			throws Exception {

		if (fileUpload != null && fileUpload.length > 0) {
			for (CommonsMultipartFile aFile : fileUpload) {
				KycFile kycFile = new KycFile();
				kycFile.setData(aFile.getBytes());
				kycFile.setDocDescription(request.getParameter("fileDesc"));
				
				kycFile.setUserId(request.getParameter("regUserId"));
				kycFile.setKycType(aFile.getOriginalFilename());
				fileUploadDao.save(kycFile);
			}
		}
		return "login";
	}

	@RequestMapping(value = { "/openDocument-{userId}" }, method = RequestMethod.GET)
	public String openDocument(@PathVariable String userId, ModelMap model) {
		List<KycFile> kycFileList = fileUploadDao.findDocumentByUserId(userId);
		model.addAttribute("kycFiles", kycFileList);
		return "viewKycDocs";
	}

	@RequestMapping(value = { "/openImage-{kycId}" }, method = RequestMethod.GET)
	public String openImage(@PathVariable int kycId, HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		KycFile kycFile = fileUploadDao.findByKycFileId(kycId);
		response.setContentType(kycFile.getKycType());
		response.setContentLength(kycFile.getData().length);
		response.setHeader("Content-Disposition", "attachment; filename=\"" + kycFile.getUserId() + "\"");

		FileCopyUtils.copy(kycFile.getData(), response.getOutputStream());
		return "viewKycDocs";

	}
}