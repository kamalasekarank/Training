package com.dhanjyothi.controller;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiary;
import com.dhanjyothi.model.Transaction;
import com.dhanjyothi.model.User;
import com.dhanjyothi.service.AccountService;
import com.dhanjyothi.service.LoginService;;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class FundTransferController {
	
	@Autowired
	AccountService accountService;
	@Autowired
	LoginService userService;
	
	@Autowired
	MessageSource messageSource;

	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

	@RequestMapping(value = { "/newTransaction" }, method = RequestMethod.GET)
	public String newTransaction(ModelMap model) {
		Transaction transaction = new Transaction();
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("transaction", transaction);
		model.addAttribute("edit", false);
		return "fundTransfer";
	}
	
	@RequestMapping(value = "/newNavTransaction-{benId}")
	public String navFundTransfer(ModelMap model, @PathVariable int benId) {
	
		Beneficiary beneficiary = accountService.findByBeneficiaryId(benId);
		Transaction transaction = new Transaction();
		model.addAttribute("transaction", transaction);
		model.addAttribute("beneficiary", beneficiary);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		return "fundTransfer";
	}

	@RequestMapping(value = { "newNavTransaction-{benId}" }, method = RequestMethod.POST)
	public String saveTransaction(@Valid Transaction transaction, BindingResult result, ModelMap model,@PathVariable int benId) {
		if (result.hasErrors()) {
			return "fundTransfer";
		}
		String userName = getPrincipal();
		User user = userService.findByUserName(userName);
		transaction.setTransType("Fund Transaction from "+getPrincipal());
		transaction.setLoggedUserId(user.getId());
		transaction.setTransDateTime(new Date());
		accountService.doTransaction(transaction);
		
	
		Account sbAccount = accountService.findByAccountUserId(user.getId());
		Float accountbalance = (sbAccount.getAccountBalance() - transaction.getTransAmount());
		sbAccount.setAccountBalance(accountbalance);
		accountService.updateAccount(sbAccount);
		
		// add the amount to payee account
		Beneficiary beneficiary = accountService.findByBeneficiaryId(benId);
		int beneAccountNum = beneficiary.getBenAccountNumber();
		Account beneAccount = accountService.findByAccountId(beneAccountNum);
		beneAccount.setAccountBalance(beneAccount.getAccountBalance()+transaction.getTransAmount());
		accountService.updateAccount(beneAccount);
		
		model.addAttribute("account", sbAccount);
		model.addAttribute("termAccounts", accountService.findAllAccounts(user.getId()));
		model.addAttribute("loggedinuser", getPrincipal());
		List<User> users = userService.findAllUsers();
		model.addAttribute("users", users);
		return "accountsummary";
	}
	
	@RequestMapping(value =  "/listtrans" , method = RequestMethod.GET)
	public String listTransaction(ModelMap model) {
		String userName = getPrincipal();
		User user = userService.findByUserName(userName);
		List<Transaction> transactions = accountService.findAllTransaction(user.getId());
		model.addAttribute("transactions", transactions);
		model.addAttribute("loggedinuser", getPrincipal());
		return "accountstatement";
	}
	
	private String getPrincipal() {
		String userId = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userId = ((UserDetails) principal).getUsername();
		} else {
			userId = principal.toString();
		}
		return userId;
	}
}