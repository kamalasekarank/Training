package com.dhanjyothi.service;

import java.util.List;

import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiary;
import com.dhanjyothi.model.ServiceRequest;
import com.dhanjyothi.model.Transaction;

public interface AccountService {

	Account findByAccountId(int id);

	Account findByAccountUserId(int userId);

	void saveAccount(Account account);

	void updateAccount(Account account);

	List<Account> findAllAccounts(int userId);

	void saveBeneficiary(Beneficiary beneficiary);

	List<Beneficiary> findAllBeneficiary(int userId);

	Beneficiary findByBeneficiaryId(int benId);

	void saveServiceRequest(ServiceRequest serviceRequest);

	List<ServiceRequest> findAllServiceRequest();

	List<Transaction> findAllTransaction(int userId);

	void doTransaction(Transaction transaction);
}