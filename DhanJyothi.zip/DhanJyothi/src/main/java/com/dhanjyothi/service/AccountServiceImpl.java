package com.dhanjyothi.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dhanjyothi.dao.AccountDao;
import com.dhanjyothi.dao.BeneficiaryDao;
import com.dhanjyothi.dao.ServiceRequestDao;
import com.dhanjyothi.dao.TransactionDao;
import com.dhanjyothi.model.Account;
import com.dhanjyothi.model.Beneficiary;
import com.dhanjyothi.model.ServiceRequest;
import com.dhanjyothi.model.Transaction;

@Service("accountService")
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao dao;

	@Autowired
	private BeneficiaryDao beneDao;

	@Autowired
	private ServiceRequestDao serviceReqDao;

	@Autowired
	private TransactionDao transactionDao;

	public Account findByAccountId(int id) {
		return dao.findByAccountId(id);
	}

	public void saveAccount(Account account) {
		dao.save(account);
	}

	public void updateAccount(Account account) {
		Account entity = dao.findByAccountId(account.getId());
		if (entity != null) {
			entity.setAccountType(account.getAccountType());
			entity.setAccountBalance(account.getAccountBalance());
			entity.setDepositTenure(account.getDepositTenure());
			entity.setIntRate(account.getIntRate());
			entity.setMaturityAmount(account.getMaturityAmount());
			entity.setAccountUpdateDate(new Date());
		}
	}

	public List<Account> findAllAccounts(int userId) {
		return dao.findAllAccounts(userId);
	}

	public void saveServiceRequest(ServiceRequest serviceRequest) {
		serviceReqDao.save(serviceRequest);
	}

	public List<ServiceRequest> findAllServiceRequest() {
		return serviceReqDao.findAllServiceRequest();
	}

	public void saveBeneficiary(Beneficiary beneficiary) {
		beneDao.save(beneficiary);
	}

	public List<Beneficiary> findAllBeneficiary(int userId) {
		return beneDao.findAllBeneficiary(userId);
	}

	public Beneficiary findByBeneficiaryId(int benId) {
		return beneDao.findByBeneficiaryId(benId);
	}

	public void doTransaction(Transaction transaction) {
		transactionDao.doTransaction(transaction);
	}

	public List<Transaction> findAllTransaction(int userId) {
		return transactionDao.findAllTransaction(userId);
	}

	@Override
	public Account findByAccountUserId(int userId) {

		return dao.findByAccountUserId(userId);
	}

}
