package com.dhanjyothi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dhanjyothi.dao.UserDao;
import com.dhanjyothi.model.User;

@Service("userService")
@Transactional
public class LoginServiceImpl implements LoginService {

	@Autowired
	private UserDao dao;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public User findByUserId(int id) {
		return dao.findByUserId(id);
	}

	public User findByUserName(String userName) {
		System.out.println("userName :: " + userName);
		User user = dao.findByUserName(userName);
		return user;
	}

	public void saveUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		dao.save(user);
	}

	public void updateUser(User user) {
		dao.updateUser(user);
	}

	public void deleteUserByUserId(int id) {
		dao.deleteByUserId(id);
	}

	public List<User> findAllUsers() {
		return dao.findAllUsers();
	}

	public boolean isUserSSOUnique(Integer id, String userName) {
		User user = findByUserName(userName);
		return (user == null || ((id != null) && (user.getId() == id)));
	}

}
