package com.dhanjyothi.dao;

import java.util.List;

import com.dhanjyothi.model.User;


public interface UserDao {

	User findByUserId(int id);
	
	User findByUserName(String sso);
	
	void save(User user);
	
	void deleteByUserName(String sso);
	
	List<User> findAllUsers();

}

