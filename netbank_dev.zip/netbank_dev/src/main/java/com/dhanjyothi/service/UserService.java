package com.dhanjyothi.service;

import java.util.List;

import com.dhanjyothi.model.User;


public interface UserService {
	
	User findByUserId(int id);
	
	User findByUserName(String userName);
	
	void saveUser(User user);
	
	void updateUser(User user);
	
	void deleteUserByUserName(String sso);

	List<User> findAllUsers(); 
	
	boolean isUserSSOUnique(Integer id, String userName);

}